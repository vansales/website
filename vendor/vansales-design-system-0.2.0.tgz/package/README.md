# Vansales Design System

A **shadcn/ui-based** React component library themed to the Vansales brand. Built for the Vansales sales-management product — modern, accessible, and syncable to claude.ai/design.

## Theme

| Token | Value |
|---|---|
| primary | `#1765B3` → `hsl(210 77% 40%)` (Vansales blue) |
| base neutrals | zinc |
| success / warning / destructive | `#198754` / `#ffc107` / `#dc3545` (app-aligned) |
| font (UI) | **IBM Plex Sans Thai** |
| font (display) | Anuphan |
| radius | `0.5rem` |

Color is driven entirely by CSS variables in `src/styles/globals.css` (the shadcn token system) — change `--primary` once and the whole library re-themes. Full light + dark mode.

## Stack

- React 18 + TypeScript
- Tailwind CSS 3 + Radix UI primitives + class-variance-authority (the shadcn/ui approach — components live in this repo, fully owned)
- Vite library build → `dist/` (ESM + UMD on `window.VansalesDS`, single compiled stylesheet, `.d.ts`)
- Storybook 8 for stories/previews

## Logo

`Logo` (`variant="wordmark" | "mark"`) is inline SVG (`fill: currentColor`) — crisp at any size and recolorable via the `color` prop (default `#1765B3`). Wordmark and mark share one traced vector (`src/components/Logo/logo-art.ts`); the mark is the wordmark's own icon, cropped. Standalone files: `src/assets/vansales-logo.svg`, `src/assets/vansales-mark.svg`.

> **Original logo font:** the wordmark lettering ("vansales") is the **Righteous** typeface (Google Fonts). It's vectorized in the SVG, so it's not a runtime dependency — use Righteous when recreating or extending the logo lettering.

## Components (23)

**Forms** — Button · Input · Textarea · Label · Select · Checkbox · Switch · RadioGroup
**Display** — Badge · Card · Stat · Table · Alert · Progress · Spinner · Avatar · Separator
**Overlay** — Dialog · DropdownMenu · Tooltip
**Navigation** — Tabs · Pagination · Breadcrumb · Sidebar

All examples use Thai sales-domain content (คำสั่งซื้อ, ลูกค้า, สถานะชำระเงิน).

## Develop

```bash
pnpm install
pnpm storybook       # http://localhost:6006
pnpm build           # dist/ (bundle + css + types)
pnpm build-storybook # static storybook
```

## Usage

```tsx
import { Button, Card, CardHeader, CardTitle, Stat } from "@vansales/design-system";
import "@vansales/design-system/styles.css";

<Card>
  <CardHeader><CardTitle>ยอดขายวันนี้</CardTitle></CardHeader>
  <Stat label="วันนี้" value="฿128,400" hint="▲ 12%" trend="up" />
  <Button>สร้างคำสั่งซื้อ</Button>
</Card>;
```

> The previous Bootstrap 5 version is preserved on the `bootstrap-version` git branch.
